<?php
//sertakan filenya
require_once 'latihan14a.php';

echo tambah(50,30);
?>