<?php
//sertakan file classnya
require_once 'Siswa.php';

//ciptakan objek
$ns1 = new Siswa();
$ns1->nama = "Jamal";
$ns1->nilai = 40;
$ns1->pelajaran = "PHP";

//cetak
echo $ns1->nama;
echo $ns1->nilai;
echo $ns1->pelajaran;
echo $ns1->getHasil();
?>