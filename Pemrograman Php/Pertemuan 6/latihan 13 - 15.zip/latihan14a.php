<?php
//fungsi dengan return (mengembalikan nilai)
function tambah($a, $b){
    $c = $a + $b;
    return $c;
}
?>